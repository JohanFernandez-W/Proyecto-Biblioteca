﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Identity.Client;
using Software_Biblioteca.Models;

namespace Software_Biblioteca.Data
{
    public class AppDbContext : DbContext
    {
        
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }
        public DbSet<ApiLibro> LIBROS { get; set; }
        public DbSet<Usuario> USUARIOS { get; set; }
        public DbSet<VideoBeam> VIDEOBEAMS{ get; set; }
        public DbSet<Ubicacion> UBICACION { get; set; }
        public DbSet<Reservas_Salon> RESERVA_SALON { get; set; }
        public DbSet<Prestamos> PRESTAMOS { get; set; }
    }
}

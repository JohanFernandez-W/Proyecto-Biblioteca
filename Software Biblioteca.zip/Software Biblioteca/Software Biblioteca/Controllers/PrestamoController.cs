﻿using Microsoft.AspNetCore.Mvc;
using Software_Biblioteca.Data;
using Software_Biblioteca.Models;

namespace Software_Biblioteca.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class PrestamoController: ControllerBase
    {
        private readonly AppDbContext _context;

        public PrestamoController(AppDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public ActionResult<IEnumerable<Prestamos>> GetPrestamo()
        {
            return _context.PRESTAMOS.ToList();
        }

        [HttpPost]
        public ActionResult<Prestamos> PostPrestamo(Prestamos Presta)
        {
            _context.PRESTAMOS.Add(Presta);
            _context.SaveChanges();
            return CreatedAtAction(nameof(GetPrestamo), new { id = Presta.Id_prestamo }, Presta);
        }


        [HttpPut("{id}")]
        public IActionResult PutPrestamo(int id, Prestamos presta)
        {
            // Mira si existe en la tabla
            var existingPresta = _context.PRESTAMOS.FirstOrDefault(l => l.Id_prestamo == id);
            if (existingPresta == null)
            {
                return NotFound();
            }

            // Update the libro details
            existingPresta .Id_usuario = presta.Id_usuario;
            existingPresta.Id_libro = presta.Id_libro;
            existingPresta.Id_videobeams = presta.Id_videobeams;
            existingPresta.Id_reserva = presta.Id_reserva;
            existingPresta .fecha_y_hora_prestamo = presta.fecha_y_hora_prestamo;
            existingPresta.fecha_y_hora_devolucion= presta.fecha_y_hora_devolucion;
            // Add any other properties to update as needed

            _context.SaveChanges();
            return NoContent();
        }
    }
}

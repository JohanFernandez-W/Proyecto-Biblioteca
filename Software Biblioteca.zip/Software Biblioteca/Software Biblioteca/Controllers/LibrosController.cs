﻿using Microsoft.AspNetCore.Mvc;
using Software_Biblioteca.Models;
using Software_Biblioteca.Data;
using System.Collections.Generic;
using System.Linq;

namespace Software_Biblioteca.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class LibrosController : ControllerBase
    {
        private readonly AppDbContext _context;

        public LibrosController(AppDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public ActionResult<IEnumerable<ApiLibro>> GetLibros()
        {
            return _context.LIBROS.ToList();
        }

        [HttpPost]
        public ActionResult<ApiLibro> PostLibro(ApiLibro libro)
        {
            _context.LIBROS.Add(libro);
            _context.SaveChanges();
            return CreatedAtAction(nameof(GetLibros), new { id = libro.Id_libros }, libro);
        }

       
        [HttpPut("{id}")]
        public IActionResult PutLibro(int id, ApiLibro libro)
        {
            // Mira si existe en la tabla
            var existingLibro = _context.LIBROS.FirstOrDefault(l => l.Id_libros == id);
            if (existingLibro == null)
            {
                return NotFound();
            }

            // Update the libro details
            existingLibro.titulo = libro.titulo;
            existingLibro.id_ubicacion = libro.id_ubicacion;
            existingLibro.editorial = libro.editorial;
            existingLibro.fecha_publicacion = libro.fecha_publicacion;
            existingLibro.categoria= libro.categoria;
            // Add any other properties to update as needed

            _context.SaveChanges();
            return NoContent(); 
        }

        
        [HttpDelete("{id}")]
        public IActionResult DeleteLibro(int id)
        {

            // Mira si existe en la tabla
            var libro = _context.LIBROS.FirstOrDefault(l => l.Id_libros == id);
            if (libro == null)
            {
                return NotFound();
            }

            // borra de la base de datos
            _context.LIBROS.Remove(libro);
            _context.SaveChanges();
            return NoContent(); 
        }
    }
}
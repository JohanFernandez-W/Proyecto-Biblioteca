﻿
using Microsoft.AspNetCore.Mvc;
using Software_Biblioteca.Data;
using Software_Biblioteca.Models;

namespace Software_Biblioteca.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class ReservaSalonController:ControllerBase
    {
        private readonly AppDbContext _context;

        public ReservaSalonController(AppDbContext context)
        {
            _context = context;
        }
        [HttpGet]
        public ActionResult<IEnumerable<Reservas_Salon>> GetReserva()
        {
            return _context.RESERVA_SALON.ToList();
        }

        [HttpPost]
        public ActionResult<Reservas_Salon> PostReserva(Reservas_Salon reserva)
        {
            _context.RESERVA_SALON.Add(reserva);
            _context.SaveChanges();
            return CreatedAtAction(nameof(GetReserva), new { id = reserva.Id_reserva }, reserva);
        }


        [HttpPut("{id}")]
        public IActionResult PutUsuario(int id, Reservas_Salon reserva)
        {
            // Mira si existe en la tabla
            var existingReserva = _context.RESERVA_SALON.FirstOrDefault(l => l.Id_reserva == id);
            if (existingReserva == null)
            {
                return NotFound();
            }

            // Update the libro details
            existingReserva.fecha_reserva = reserva.fecha_reserva;
            existingReserva.fecha_y_hora_inicio = reserva.fecha_y_hora_inicio;
            existingReserva.fecha_y_hora_fin = reserva.fecha_y_hora_fin;
            existingReserva.Estado_Salon = reserva.Estado_Salon;
            // Add any other properties to update as needed

            _context.SaveChanges();
            return NoContent();
        }
    }
}

﻿using Microsoft.AspNetCore.Mvc;
using Software_Biblioteca.Models;
using Software_Biblioteca.Data;
using System.Collections.Generic;
using System.Linq;

namespace Software_Biblioteca.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class UsuarioController:ControllerBase
    {
        private readonly AppDbContext _context;

        public UsuarioController(AppDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public ActionResult<IEnumerable<Usuario>> GetUsuarios()
        {
            return _context.USUARIOS.ToList();
        }

        [HttpPost]
        public ActionResult<Usuario> PostUsuario(Usuario cliente)
        {
            _context.USUARIOS.Add(cliente);
            _context.SaveChanges();
            return CreatedAtAction(nameof(GetUsuarios), new { id = cliente.Id_Usuarios }, cliente);
        }


        [HttpPut("{id}")]
        public IActionResult PutUsuario(int id, Usuario cliente)
        {
            // Mira si existe en la tabla
            var existingUsuario = _context.USUARIOS.FirstOrDefault(l => l.Id_Usuarios == id);
            if (existingUsuario == null)
            {
                return NotFound();
            }

            // Update the libro details
            existingUsuario.nombre = cliente.nombre;
            existingUsuario.apellido = cliente.apellido;
            existingUsuario.cedula = cliente.cedula;
            existingUsuario.correo = cliente.correo;
            // Add any other properties to update as needed

            _context.SaveChanges();
            return NoContent();
        }


        [HttpDelete("{id}")]
        public IActionResult DeleteUsuario(int id)
        {

            // Mira si existe en la tabla
            var cliente = _context.USUARIOS.FirstOrDefault(l => l.Id_Usuarios== id);
            if (cliente == null)
            {
                return NotFound();
            }

            // borra de la base de datos
            _context.USUARIOS.Remove(cliente);
            _context.SaveChanges();
            return NoContent();
        }

    }
}

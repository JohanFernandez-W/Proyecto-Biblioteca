﻿using Microsoft.AspNetCore.Mvc;
using Software_Biblioteca.Models;
using Software_Biblioteca.Data;
using System.Collections.Generic;
using System.Linq;

namespace Software_Biblioteca.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class UbicacionController: ControllerBase
    {
        private readonly AppDbContext _context;

        public UbicacionController(AppDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public ActionResult<IEnumerable<Ubicacion>> GetUbicacion()
        {
            return _context.UBICACION.ToList();
        }

        [HttpPost]
        public ActionResult<Ubicacion> PostUbicacion(Ubicacion lugar)
        {
            _context.UBICACION.Add(lugar);
            _context.SaveChanges();
            return CreatedAtAction(nameof(GetUbicacion), new { id = lugar.Id_ubicacion }, lugar);
        }
    }
}

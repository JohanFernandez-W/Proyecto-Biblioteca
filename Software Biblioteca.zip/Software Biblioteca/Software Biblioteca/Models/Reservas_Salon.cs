﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Software_Biblioteca.Models
{
    public class Reservas_Salon
    {
        [Key]
        [Column("Id_ReservaSalon")]

        public int Id_reserva{  get; set; }
        [Required]
        public DateTime fecha_reserva {  get; set; }
        [Required]
        public DateTime fecha_y_hora_inicio {  get; set; }
        [Required]
        public DateTime fecha_y_hora_fin {  get; set; }
        [Required]
        public string Estado_Salon {  get; set; }
    }
}

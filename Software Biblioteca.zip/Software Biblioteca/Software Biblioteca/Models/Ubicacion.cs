﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Software_Biblioteca.Models
{
    public class Ubicacion
    {
        [Key]
        [Column("Id_ubicacion")]

        public int Id_ubicacion { get; set; }
        [Required]
        public string Lugar {  get; set; }


    }
}

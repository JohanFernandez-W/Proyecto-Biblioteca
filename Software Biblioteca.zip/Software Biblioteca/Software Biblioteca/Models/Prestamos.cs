﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Software_Biblioteca.Models
{
    public class Prestamos
    {
        [Key]
        [Column("Id_prestamo")]

        public int Id_prestamo {  get; set; }
        [ForeignKey("Id_usuario")]
        public int Id_usuario { get; set; }
        [ForeignKey("Id_libro")]
        public int Id_libro { get; set; }
        [ForeignKey("Id_videobeams")]
        public int Id_videobeams { get; set; }
        [ForeignKey("Id_reserva")]
        public int Id_reserva { get; set; }
        [Required]
        public DateTime fecha_y_hora_prestamo { get; set; }
        [Required]
        public DateTime fecha_y_hora_devolucion{ get; set; }



    }
}

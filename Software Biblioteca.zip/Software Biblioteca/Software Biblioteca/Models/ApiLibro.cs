﻿

using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Software_Biblioteca.Models
{
    
    public class ApiLibro
    {
        [Key]
        [Column("Id_libros")]
        public int Id_libros {  get; set; }

        [Required]
        public string titulo { get; set; }

        [ForeignKey("Id_ubicacion")]
        public int id_ubicacion { get; set; }
        [Required]
        public string editorial { get; set; }
        [Required]
        [DataType(DataType.Date)]
        public DateTime fecha_publicacion { get; set; }

        [Required]

        public string categoria { get; set; }

        [Required]
        public string Estado_Libro { get; set; } 
    }
}

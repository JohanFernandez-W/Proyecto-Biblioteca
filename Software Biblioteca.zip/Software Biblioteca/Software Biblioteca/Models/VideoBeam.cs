﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Software_Biblioteca.Models
{
    public class VideoBeam
    {
        [Key]
        [Column("Id_videobeams")]
        public int  Id_Videobeams { get; set; }
        [Required]
        public string marca {  get; set; }
        [Required]
        public string condicion {  get; set; }

        [Required]
        public string descripcion {  get; set; }
        [Required]
        public string Estado_VideoBeams { get; set; }

    }
}

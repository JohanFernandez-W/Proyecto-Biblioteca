﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Software_Biblioteca.Models
{
    public class Usuario
    {
        [Key]
        [Column("Id_usuario")]

        public int Id_Usuarios { get; set; }

        [Required]
        public string nombre { get; set; }
        [Required]
        public string apellido { get; set; }
        [Required]
        public int cedula { get; set; }
        [Required]
        public int telefono { get; set; } 
        [Required]
        public string correo {  get; set; }

    }
}
